# frontend-gulp
Bu front-end işlerinize gulp ile başlamanız için bir başlangıç paketidir.

# Kurulum
Repoyu uygun bir yere klonlayın.
```
git clone https://github.com/tayfunerbilen/frontend-gulp.git .
```
Daha sonra paketleri kurun.
```
npm install -y
```
Ve artık çalıştırmaya hazırsınız.
```
sudo gulp
```